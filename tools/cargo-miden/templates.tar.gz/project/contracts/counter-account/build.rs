//! Populates the Miden package cache for builds that `midenc` does not drive.
//!
//! Plain `cargo check`, `cargo build`, and IDE analysis expand the Miden SDK macros without a
//! surrounding `cargo miden build`. Those macros read compiled dependency packages from the
//! directory named by `MIDENC_PACKAGE_CACHE`. The compiler's own package cache is deleted when
//! each build ends, so this script stages generations of its own under `OUT_DIR`, fills the
//! next generation with a nested `cargo miden build` that adopts it through the same variable,
//! and exports the variable to the compilation of this crate.
//!
//! Staging is generational so the exported directory is always one consistent build: the
//! nested build fills a fresh generation, and only a fully successful build moves the current
//! pointer. A failed build keeps exporting the previous generation whole — never a mix of new
//! and old packages — and if no good generation exists yet, the script fails the outer build.
//!
//! The nested build runs whenever cargo re-runs this script. The script watches the project
//! manifests and, through the watch lists the compiler writes next to the staged packages, the
//! source inputs of every resolved dependency — so editing a dependency re-stages its package
//! on the next check.
//!
//! One sharing caveat: cargo keys build-script output by crate name and version, not by
//! project path. Two different projects with the same package name and version that share one
//! `CARGO_TARGET_DIR` reuse each other's script output, including this staged cache. Use
//! per-checkout target directories for such layouts.
//!
//! See <https://github.com/0xMiden/compiler/issues/1298>.

use std::{
    env, fs,
    path::{Path, PathBuf},
    process::{Command, Output},
};

fn main() {
    // The manifests declare the dependency set this script stages packages for. Naming any
    // watch disables cargo's watch-everything default, which would otherwise re-run the
    // nested build after every source edit of this crate.
    println!("cargo:rerun-if-changed=miden-project.toml");
    println!("cargo:rerun-if-changed=Cargo.toml");
    // Re-evaluate when the build mode or the tool selection changes.
    println!("cargo:rerun-if-env-changed=MIDENC_PACKAGE_CACHE");
    println!("cargo:rerun-if-env-changed=CARGO_MIDEN");
    // These inputs shape the compiled packages.
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    println!("cargo:rerun-if-env-changed=RUSTUP_TOOLCHAIN");

    // Inside a midenc-driven build the compiler owns the package cache, macro expansion
    // already sees the variable, and a nested build would recurse into this script forever.
    // An empty value counts as unset, matching the compiler and the SDK macros.
    if env::var_os("MIDENC_PACKAGE_CACHE").is_some_and(|value| !value.is_empty()) {
        return;
    }

    let manifest_dir = PathBuf::from(env::var_os("CARGO_MANIFEST_DIR").unwrap());
    let out_dir = PathBuf::from(env::var_os("OUT_DIR").unwrap());
    // Generations live under this script's OUT_DIR, so they belong to this crate and build
    // configuration and are removed by `cargo clean`.
    let generations = out_dir.join("miden-packages");
    let pointer = out_dir.join("miden-packages.current");

    // Alternate between two generations: the pointer names the last good one, the nested
    // build fills the other from scratch (which also drops packages of removed
    // dependencies).
    let current = fs::read_to_string(&pointer)
        .ok()
        .map(|name| name.trim().to_string())
        .filter(|name| name == "gen-0" || name == "gen-1")
        .filter(|name| generations.join(name).is_dir());
    let next = match current.as_deref() {
        Some("gen-0") => "gen-1",
        _ => "gen-0",
    };
    let next_dir = generations.join(next);
    let _ = fs::remove_dir_all(&next_dir);
    fs::create_dir_all(&next_dir).expect("failed to create the Miden package cache generation");

    // Stage the dependency packages: the nested compiler adopts the generation through
    // MIDENC_PACKAGE_CACHE, publishes every dependency package into it before the root
    // target compiles, and leaves the directory in place for the outer build to read.
    let build = run_cargo_miden_build(&manifest_dir, &next_dir);
    let exported = if build.status.success() {
        // Only a complete generation becomes current. The pointer write is the publication
        // step: a crash before it leaves the previous generation exported.
        let staged = pointer.with_extension("current.tmp");
        fs::write(&staged, next).expect("failed to stage the Miden package cache pointer");
        fs::rename(&staged, &pointer).expect("failed to publish the Miden package cache pointer");
        next_dir
    } else {
        let stderr = String::from_utf8_lossy(&build.stderr);
        // A missing `cargo miden` plugin is a setup error, not a broken build; surface it
        // with instructions instead of a stale-packages warning.
        if stderr.contains("no such command") || stderr.contains("no such subcommand") {
            panic!(
                "`cargo miden build` failed ({}): the `cargo miden` plugin was not \
                 found.\nInstall cargo-miden (`cargo install cargo-miden`) or point the \
                 CARGO_MIDEN environment variable at a cargo-miden binary.",
                build.status,
            );
        }
        match current {
            // "Stale beats broken": the previous generation is a consistent package set, and
            // analyzing against it beats failing the whole check while a dependency is
            // mid-edit.
            Some(current) => {
                println!(
                    "cargo:warning=`cargo miden build --release` failed ({}); analyzing against \
                     the previously staged dependency packages: {}",
                    build.status,
                    last_stderr_line(&build.stderr),
                );
                generations.join(current)
            }
            // With no good generation there is nothing consistent to export; failing here is
            // clearer than every macro expansion failing on missing packages.
            None => panic!(
                "`cargo miden build --release` failed ({}) and no previously staged dependency \
                 packages exist:\n{}",
                build.status,
                String::from_utf8_lossy(&build.stderr),
            ),
        }
    };

    // Watch the resolved dependency inputs recorded by the compiler, so editing a dependency
    // re-runs this script and re-stages its package. One absolute path per line, one file per
    // resolved consumer project.
    let watch_dir = exported.join("miden-deps");
    if let Ok(entries) = fs::read_dir(&watch_dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if path.extension().is_some_and(|extension| extension == "watch")
                && let Ok(watch_list) = fs::read_to_string(&path)
            {
                for line in watch_list.lines().map(str::trim).filter(|line| !line.is_empty()) {
                    // Watch only paths that exist: cargo re-runs a build script
                    // unconditionally while a watched path is missing.
                    if Path::new(line).exists() {
                        println!("cargo:rerun-if-changed={line}");
                    }
                }
            }
        }
    }

    println!("cargo:rustc-env=MIDENC_PACKAGE_CACHE={}", exported.display());
}

/// Runs `cargo miden build --release` for the project in `manifest_dir`, staging the
/// dependency packages into `cache_dir`.
///
/// `CARGO_MIDEN` selects a specific `cargo-miden` binary; otherwise the `cargo miden` plugin
/// is resolved through the `cargo` that drives this build. The nested build gets its own
/// cargo target directory: the outer cargo holds a lock on this build's target directory
/// while build scripts run, and a nested build against the same directory would deadlock.
fn run_cargo_miden_build(manifest_dir: &Path, cache_dir: &Path) -> Output {
    let mut command = match env::var_os("CARGO_MIDEN") {
        Some(cargo_miden) => Command::new(cargo_miden),
        None => Command::new(env::var_os("CARGO").unwrap_or_else(|| "cargo".into())),
    };
    command
        .args(["miden", "build", "--release"])
        .current_dir(manifest_dir)
        .env("MIDENC_PACKAGE_CACHE", cache_dir)
        .env(
            "CARGO_TARGET_DIR",
            manifest_dir.join("target").join("miden").join("build-script"),
        );
    command.output().unwrap_or_else(|err| {
        panic!(
            "failed to run `cargo miden build`: {err}.\nInstall cargo-miden (`cargo install \
             cargo-miden`) or point the CARGO_MIDEN environment variable at a cargo-miden \
             binary."
        )
    })
}

/// Returns the last non-empty stderr line for a compact warning.
fn last_stderr_line(stderr: &[u8]) -> String {
    String::from_utf8_lossy(stderr)
        .lines()
        .rev()
        .find(|line| !line.trim().is_empty())
        .unwrap_or("no error output")
        .to_string()
}
